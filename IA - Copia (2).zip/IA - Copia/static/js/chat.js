document.addEventListener('DOMContentLoaded', () => {

    const chatForm = document.getElementById('chat-form');
    const mensagemInput = document.getElementById('mensagem-input');
    const arquivosInput = document.getElementById('arquivo-input');
    const conversaMensagens = document.getElementById('messages-container');
    const conversaList = document.getElementById('conversa-list');
    const chatTitle = document.getElementById('chat-title');
    const chatSubtitle = document.getElementById('chat-subtitle');
    const conversaIdInput = document.getElementById('conversa-id');
    const novaConversaBtn = document.getElementById('nova-conversa-btn');
    const personalidadeSelect = document.getElementById('personalidade-select');
    const placeholderMessage = document.getElementById('no-chat-message');
    const typingIndicator = document.getElementById('typing-indicator');
    const sendButton = document.getElementById('send-button');
    const attachedFiles = document.getElementById('attached-files');
    const filesList = document.getElementById('files-list');
    const promptSuggestions = document.getElementById('prompt-suggestions');
    const shareBtn = document.getElementById('share-btn');
    const analyticsBtn = document.getElementById('analytics-btn');
    const settingsBtn = document.getElementById('settings-btn');
    const responseTimeIndicator = document.getElementById('response-time-indicator');
    const responseTimeText = document.getElementById('response-time-text');
    const tokenCountSidebar = document.getElementById('token-count-sidebar');
    const toggleSidebarBtn = document.getElementById('toggle-sidebar-btn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');

    let isFetchingResponse = false;
    let currentConversationId = null;
    let attachedFilesArray = [];

    // Função para obter token CSRF
    function getCSRFToken() {
        const token = document.querySelector('[name=csrfmiddlewaretoken]');
        return token ? token.value : '';
    }

    // Função para carregar personalidades
    async function carregarPersonalidades() {
        try {
            const response = await fetch('/api/personalidades/');
            const data = await response.json();
            if (data.personalidades) {
                personalidadeSelect.innerHTML = data.personalidades.map(p =>
                    `<option value="${p.nome}" data-foto="${p.foto_ia_url}">${p.nome}</option>`
                ).join('');
            }
        } catch (error) {
            console.error('Erro ao carregar personalidades:', error);
        }
    }

    // Função para carregar lista de conversas
    async function carregarConversas() {
        try {
            const response = await fetch('/api/conversas/');
            const data = await response.json();
            conversaList.innerHTML = '';
            if (data.conversas) {
                data.conversas.forEach(conversa => {
                    const li = document.createElement('li');
                    li.className = 'chat-list-item';
                    li.dataset.conversaId = conversa.id;
                    li.innerHTML = `<strong>${conversa.titulo}</strong><br><small class="text-muted">${conversa.modificado_em.split('T')[0]}</small>`;
                    li.addEventListener('click', () => carregarConversa(conversa.id));
                    conversaList.appendChild(li);
                });
            }
        } catch (error) {
            console.error('Erro ao carregar conversas:', error);
        }
    }

    // Função para carregar mensagens de uma conversa específica
    async function carregarConversa(conversaId) {
        placeholderMessage.style.display = 'none';
        conversaMensagens.innerHTML = '';

        document.querySelectorAll('.chat-list-item').forEach(el => el.classList.remove('active'));
        const activeItem = document.querySelector(`.chat-list-item[data-conversa-id="${conversaId}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }

        try {
            const response = await fetch(`/api/conversas/${conversaId}/`);
            const data = await response.json();

            chatTitle.textContent = data.titulo;
            conversaIdInput.value = data.conversa_id;
            currentConversationId = data.conversa_id;
            personalidadeSelect.value = data.personalidade_id;

            data.mensagens.forEach(mensagem => {
                console.log('Carregando mensagem:', mensagem.id, 'papel:', mensagem.papel, 'audio_url:', mensagem.audio_url);
                adicionarMensagemNaUI(mensagem.texto_html, mensagem.papel, mensagem.tipo_conteudo, mensagem.dados_conteudo, mensagem.id, null, null, mensagem.audio_url);
            });

            conversaMensagens.scrollTop = conversaMensagens.scrollHeight;
            
            // Configurar listeners para mensagens carregadas
            setupReactionListeners();
            setupRatingListeners();
            setupAudioListeners();
        } catch (error) {
            console.error('Erro ao carregar conversa:', error);
        }
    }

    // Função para adicionar uma mensagem à UI
    function adicionarMensagemNaUI(texto, papel, tipo, dados, mensagemId = null, timestamp = null, status = 'sent', audioUrl = null) {
        console.log('adicionarMensagemNaUI chamado:', { texto: texto?.substring(0, 50), papel, tipo, mensagemId, audioUrl });
        const messageWrapper = document.createElement('div');
        messageWrapper.className = `message-wrapper ${papel === 'user' ? 'message-user-wrapper' : 'message-assistant-wrapper'}`;

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${papel === 'user' ? 'message-user' : 'message-assistant'}`;

        // Avatar
        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        if (papel === 'user') {
            avatarDiv.innerHTML = '<i class="fas fa-user"></i>';
        } else {
            avatarDiv.innerHTML = '<i class="fas fa-robot"></i>';
        }
        messageDiv.appendChild(avatarDiv);

        // Conteúdo da mensagem
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';

        if (tipo === 'text') {
            contentDiv.innerHTML = texto;
        } else if (tipo === 'image' && dados) {
            contentDiv.innerHTML = `<p>${texto}</p><img src="${dados}" alt="Imagem gerada" class="message-image">`;
        } else if (tipo === 'file' && texto) {
            contentDiv.innerHTML = `<p>${texto}</p>`;
        } else {
            contentDiv.innerHTML = `<p>${texto}</p>`;
        }

        // Timestamp e status
        const metaDiv = document.createElement('div');
        metaDiv.className = 'message-meta';

        if (timestamp) {
            const timeSpan = document.createElement('span');
            timeSpan.className = 'message-time';
            timeSpan.textContent = formatTime(timestamp);
            metaDiv.appendChild(timeSpan);
        }

        if (papel === 'user') {
            const statusSpan = document.createElement('span');
            statusSpan.className = `message-status status-${status}`;
            statusSpan.innerHTML = getStatusIcon(status);
            metaDiv.appendChild(statusSpan);
        }

        contentDiv.appendChild(metaDiv);
        messageDiv.appendChild(contentDiv);

        // Reações e ratings para mensagens do assistente
        console.log('Verificando condições para botões:', { papel, mensagemId, hasMensagemId: !!mensagemId });
        if (papel === 'assistant' && mensagemId) {
            console.log('Criando botões para mensagem do assistente');
            const reactionsDiv = document.createElement('div');
            reactionsDiv.className = 'message-reactions';

            // Audio controls - botão para gerar TTS sob demanda ou play se já existe
            const audioControls = document.createElement('div');
            audioControls.className = 'audio-controls';
            if (audioUrl && audioUrl.trim() !== '') {
                audioControls.innerHTML = `
                    <button class="audio-play-btn" data-audio-url="${audioUrl}" title="Ouvir resposta">
                        <i class="fas fa-volume-up"></i>
                    </button>
                `;
            } else {
                audioControls.innerHTML = `
                    <button class="audio-generate-btn" data-message-id="${mensagemId}" title="Gerar áudio para ouvir">
                        <i class="fas fa-volume-up"></i>
                    </button>
                `;
            }
            reactionsDiv.appendChild(audioControls);

            // Botões de reação
            const reactionButtons = document.createElement('div');
            reactionButtons.className = 'reaction-buttons';
            reactionButtons.innerHTML = `
                <button class="reaction-btn" data-reaction="👍" data-message-id="${mensagemId}" title="Gostei">
                    <i class="fas fa-thumbs-up"></i>
                </button>
                <button class="reaction-btn" data-reaction="👎" data-message-id="${mensagemId}" title="Não gostei">
                    <i class="fas fa-thumbs-down"></i>
                </button>
                <button class="reaction-btn" data-reaction="❤️" data-message-id="${mensagemId}" title="Amei">
                    <i class="fas fa-heart"></i>
                </button>
                <button class="reaction-btn" data-reaction="😂" data-message-id="${mensagemId}" title="Engraçado">
                    <i class="fas fa-laugh-squint"></i>
                </button>
            `;

            // Sistema de rating por estrelas
            const ratingDiv = document.createElement('div');
            ratingDiv.className = 'message-rating';
            ratingDiv.innerHTML = `
                <div class="stars" data-message-id="${mensagemId}">
                    <i class="far fa-star" data-rating="1"></i>
                    <i class="far fa-star" data-rating="2"></i>
                    <i class="far fa-star" data-rating="3"></i>
                    <i class="far fa-star" data-rating="4"></i>
                    <i class="far fa-star" data-rating="5"></i>
                </div>
            `;

            reactionsDiv.appendChild(reactionButtons);
            reactionsDiv.appendChild(ratingDiv);
            messageDiv.appendChild(reactionsDiv);
        }

        messageWrapper.appendChild(messageDiv);
        conversaMensagens.appendChild(messageWrapper);
        conversaMensagens.scrollTop = conversaMensagens.scrollHeight;

        if (papel === 'assistant' && mensagemId) {
            setupReactionListeners();
            setupRatingListeners();
            setupAudioListeners();
        }
    }

    // Funções auxiliares
    function formatTime(timestamp) {
        if (!timestamp) return '';
        const date = new Date(timestamp);
        return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    }

    function getStatusIcon(status) {
        switch (status) {
            case 'sent': return '<i class="fas fa-check"></i>';
            case 'delivered': return '<i class="fas fa-check-double"></i>';
            case 'read': return '<i class="fas fa-check-double text-blue"></i>';
            case 'error': return '<i class="fas fa-exclamation-triangle text-red"></i>';
            default: return '<i class="fas fa-clock"></i>';
        }
    }

    // Configurar listeners para reações
    function setupReactionListeners() {
        document.querySelectorAll('.reaction-btn').forEach(button => {
            button.addEventListener('click', async (event) => {
                const btn = event.currentTarget;
                const reaction = btn.dataset.reaction;
                const messageId = btn.dataset.messageId;

                try {
                    const response = await fetch(`/api/reactions/${messageId}/`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRFToken': getCSRFToken()
                        },
                        body: JSON.stringify({ reaction: reaction })
                    });

                    if (response.ok) {
                        // Atualizar visual da reação
                        btn.classList.toggle('active');
                        console.log('Reação enviada com sucesso.');
                    }
                } catch (error) {
                    console.error('Erro ao enviar reação:', error);
                }
            });
        });
    }

    // Configurar listeners para ratings
    function setupRatingListeners() {
        document.querySelectorAll('.stars i').forEach(star => {
            star.addEventListener('click', async (event) => {
                const clickedStar = event.currentTarget;
                const rating = parseInt(clickedStar.dataset.rating);
                const messageId = clickedStar.parentElement.dataset.messageId;
                const stars = clickedStar.parentElement.querySelectorAll('i');

                // Atualizar visual das estrelas
                stars.forEach((s, index) => {
                    if (index < rating) {
                        s.className = 'fas fa-star';
                    } else {
                        s.className = 'far fa-star';
                    }
                });

                try {
                    const response = await fetch(`/api/rating/${messageId}/`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRFToken': getCSRFToken()
                        },
                        body: JSON.stringify({
                            rating: rating,
                            criteria: {
                                relevance: rating >= 4 ? 5 : rating >= 3 ? 4 : 3,
                                accuracy: rating >= 4 ? 5 : rating >= 3 ? 4 : 3,
                                helpfulness: rating,
                                clarity: rating >= 4 ? 5 : rating >= 3 ? 4 : 3,
                                completeness: rating >= 4 ? 5 : rating >= 3 ? 4 : 3
                            }
                        })
                    });

                    if (response.ok) {
                        console.log('Rating enviado com sucesso.');
                    }
                } catch (error) {
                    console.error('Erro ao enviar rating:', error);
                }
            });
        });
    }

    // Configurar listeners para audio playback e geração
    function setupAudioListeners() {
        // Listeners para botões de geração de TTS
        document.querySelectorAll('.audio-generate-btn').forEach(button => {
            button.addEventListener('click', async (event) => {
                const btn = event.currentTarget;
                const messageId = btn.dataset.messageId;
                
                // Mostrar loading
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                btn.disabled = true;
                
                try {
                    const response = await fetch('/api/tts/gerar/', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRFToken': getCSRFToken()
                        },
                        body: JSON.stringify({ mensagem_id: messageId })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success && data.audio_url) {
                        // Substituir botão de gerar por botão de play
                        btn.className = 'audio-play-btn';
                        btn.dataset.audioUrl = data.audio_url;
                        btn.innerHTML = '<i class="fas fa-volume-up"></i>';
                        btn.title = 'Ouvir resposta';
                        btn.disabled = false;
                        
                        // Reconfigurar listeners para este botão
                        setupAudioListeners();
                    } else {
                            btn.disabled = false;
                        }, 2000);
                    }
                } catch (error) {
                    console.error('Erro ao gerar TTS:', error);
                    btn.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';
                    btn.title = 'Erro ao gerar áudio';
                    setTimeout(() => {
                            btn.innerHTML = '<i class="fas fa-volume-up"></i>';
                            btn.disabled = false;
                        }, 2000);
                }
            });
        });
        
        // Listeners para botões de play/pause de áudio existente
        document.querySelectorAll('.audio-play-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const btn = event.currentTarget;
                const audioUrl = btn.dataset.audioUrl;
                
                // Stop any currently playing audio
                const currentlyPlaying = document.querySelector('.audio-play-btn.playing');
                if (currentlyPlaying && currentlyPlaying !== btn) {
                    currentlyPlaying.classList.remove('playing');
                    currentlyPlaying.innerHTML = '<i class="fas fa-volume-up"></i>';
                    const currentAudio = currentlyPlaying.audioElement;
                    if (currentAudio) {
                        currentAudio.pause();
                        currentAudio.currentTime = 0;
                    }
                }
                
                // Toggle play/pause for this button
                if (btn.classList.contains('playing')) {
                    // Pause
                    btn.classList.remove('playing');
                    btn.innerHTML = '<i class="fas fa-volume-up"></i>';
                    if (btn.audioElement) {
                        btn.audioElement.pause();
                    }
                } else {
                    // Play
                    btn.classList.add('playing');
                    btn.innerHTML = '<i class="fas fa-pause"></i>';
                    
                    if (!btn.audioElement) {
                        btn.audioElement = new Audio(audioUrl);
                        btn.audioElement.addEventListener('ended', () => {
                            btn.classList.remove('playing');
                            btn.innerHTML = '<i class="fas fa-volume-up"></i>';
                        });
                        btn.audioElement.addEventListener('error', () => {
                            btn.classList.remove('playing');
                            btn.innerHTML = '<i class="fas fa-volume-up"></i>';
                            console.error('Erro ao reproduzir áudio');
                        });
                    }
                    
                    btn.audioElement.play().catch(error => {
                        console.error('Erro ao reproduzir áudio:', error);
                        btn.classList.remove('playing');
                        btn.innerHTML = '<i class="fas fa-volume-up"></i>';
                    });
                }
            });
        });
    }

    // Adiciona uma mensagem de "digitando"
    function adicionarMensagemCarregando() {
        typingIndicator.style.display = 'flex';
        conversaMensagens.scrollTop = conversaMensagens.scrollHeight;
    }

    // Remove a mensagem de "digitando"
    function removerMensagemCarregando() {
        typingIndicator.style.display = 'none';
    }

    // Submissão do formulário de chat
    if (chatForm) {
        chatForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            await enviarMensagem();
        });
    }

    // Event listener para o botão de enviar
    if (sendButton) {
        sendButton.addEventListener('click', async () => {
            await enviarMensagem();
        });
    }

    // Função para enviar mensagem
    async function enviarMensagem() {
        if (isFetchingResponse) {
            return;
        }

        const mensagemTexto = mensagemInput.value.trim();
        const arquivos = arquivosInput.files;

        if (!mensagemTexto && arquivos.length === 0 && attachedFilesArray.length === 0) {
            return;
        }

        isFetchingResponse = true;
        placeholderMessage.style.display = 'none';

        // Adicionar mensagem do usuário
        const timestamp = new Date().toISOString();
        adicionarMensagemNaUI(mensagemTexto, 'user', 'text', null, null, timestamp, 'sent');

        // Adicionar arquivos anexados
        if (attachedFilesArray.length > 0) {
            attachedFilesArray.forEach(file => {
                adicionarMensagemNaUI(`Arquivo anexado: ${file.name}`, 'user', 'file', null, null, timestamp, 'sent');
            });
        }

        adicionarMensagemCarregando();

        const formData = new FormData();
        formData.append('mensagem', mensagemTexto);
        formData.append('conversa_id', conversaIdInput.value);

        // Adicionar arquivos
        attachedFilesArray.forEach(file => {
            formData.append('arquivos', file);
        });

        const startTime = Date.now();

        try {
            const response = await fetch('/api/chat/stream/', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRFToken': getCSRFToken()
                }
            });

            if (!response.ok) {
                const errorText = await response.text();
                removerMensagemCarregando();
                adicionarMensagemNaUI(`Erro: ${errorText}`, 'assistant', 'text', null, null, new Date().toISOString());
                isFetchingResponse = false;
                return;
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            let respostaCompleta = '';
            let mensagemAssistenteDiv = null;
            let contentDiv = null;

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop(); // Keep incomplete line in buffer
                
                for (const line of lines) {
                    if (line.startsWith('event: ')) {
                        const eventType = line.slice(7);
                        continue;
                    }
                    if (line.startsWith('data: ')) {
                        const dataStr = line.slice(6);
                        try {
                            const data = JSON.parse(dataStr);
                            
                            if (eventType === 'chunk') {
                                respostaCompleta += data;
                                if (!mensagemAssistenteDiv) {
                                    removerMensagemCarregando();
                                    adicionarMensagemNaUI('', 'assistant', 'text', null, null, new Date().toISOString());
                                    mensagemAssistenteDiv = conversaMensagens.lastElementChild.querySelector('.message-assistant .message-content');
                                    contentDiv = mensagemAssistenteDiv.querySelector('p') || mensagemAssistenteDiv;
                                }
                                contentDiv.innerHTML = respostaCompleta;
                                conversaMensagens.scrollTop = conversaMensagens.scrollHeight;
                            } else if (eventType === 'done') {
                                const endTime = Date.now();
                                const responseTime = endTime - startTime;
                                
                                if (responseTimeIndicator && responseTimeText) {
                                    responseTimeText.textContent = `${responseTime}ms`;
                                    responseTimeIndicator.style.display = 'flex';
                                    setTimeout(() => {
                                        responseTimeIndicator.style.display = 'none';
                                    }, 3000);
                                }
                                
                                if (data.titulo && chatTitle.textContent === 'Aether IA') {
                                    chatTitle.textContent = data.titulo;
                                }
                                conversaIdInput.value = data.conversa_id;
                                
                                if (mensagemAssistenteDiv && data.mensagem_id) {
                                    const reactionsDiv = document.createElement('div');
                                    reactionsDiv.className = 'message-reactions';
                                    
                                    // Audio controls - botão para gerar TTS sob demanda
                                    const audioControls = document.createElement('div');
                                    audioControls.className = 'audio-controls';
                                    audioControls.innerHTML = `
                                        <button class="audio-generate-btn" data-message-id="${data.mensagem_id}" title="Gerar áudio para ouvir">
                                            <i class="fas fa-volume-up"></i>
                                        </button>
                                    `;
                                    reactionsDiv.appendChild(audioControls);
                                    
                                    reactionsDiv.innerHTML += `
                                        <div class="reaction-buttons">
                                            <button class="reaction-btn" data-reaction="👍" data-message-id="${data.mensagem_id}" title="Gostei">
                                                <i class="fas fa-thumbs-up"></i>
                                            </button>
                                            <button class="reaction-btn" data-reaction="👎" data-message-id="${data.mensagem_id}" title="Não gostei">
                                                <i class="fas fa-thumbs-down"></i>
                                            </button>
                                            <button class="reaction-btn" data-reaction="❤️" data-message-id="${data.mensagem_id}" title="Amei">
                                                <i class="fas fa-heart"></i>
                                            </button>
                                            <button class="reaction-btn" data-reaction="😂" data-message-id="${data.mensagem_id}" title="Engraçado">
                                                <i class="fas fa-laugh-squint"></i>
                                            </button>
                                        </div>
                                        <div class="message-rating">
                                            <div class="stars" data-message-id="${data.mensagem_id}">
                                                <i class="far fa-star" data-rating="1"></i>
                                                <i class="far fa-star" data-rating="2"></i>
                                                <i class="far fa-star" data-rating="3"></i>
                                                <i class="far fa-star" data-rating="4"></i>
                                                <i class="far fa-star" data-rating="5"></i>
                                            </div>
                                        </div>
                                    `;
                                    mensagemAssistenteDiv.appendChild(reactionsDiv);
                                    setupReactionListeners();
                                    setupRatingListeners();
                                    setupAudioListeners();
                                }
                                
                                isFetchingResponse = false;
                                return;
                            } else if (eventType === 'error') {
                                removerMensagemCarregando();
                                adicionarMensagemNaUI(`Erro: ${data}`, 'assistant', 'text', null, null, new Date().toISOString());
                                isFetchingResponse = false;
                                return;
                            }
                        } catch (e) {
                            console.error('Erro ao parsear dados SSE:', e);
                        }
                    }
                }
            }
            currentConversationId = data.conversa_id;
            carregarConversas();

            // Limpar input e arquivos
            mensagemInput.value = '';
            attachedFilesArray = [];
            updateAttachedFilesDisplay();
            sendButton.classList.add('hidden-send-button');

        } catch (error) {
            removerMensagemCarregando();
            console.error('Erro na requisição:', error);
            const userError = error.message.includes("Unexpected token") ?
                              "Erro de comunicação com o servidor. Tente novamente." :
                              error.message;
            adicionarMensagemNaUI(`Desculpe, houve um erro ao processar sua solicitação: ${userError}`, 'assistant', 'text', null, null, new Date().toISOString());
        } finally {
            isFetchingResponse = false;
        }
    }

    // Funcionalidades para arquivos anexados
    function updateAttachedFilesDisplay() {
        if (attachedFilesArray.length > 0) {
            attachedFiles.style.display = 'block';
            filesList.innerHTML = attachedFilesArray.map((file, index) => `
                <div class="file-item">
                    <span class="file-name">${file.name}</span>
                    <span class="file-size">(${formatFileSize(file.size)})</span>
                    <button class="remove-file-btn" data-index="${index}">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `).join('');

            // Adicionar listeners para remover arquivos
            document.querySelectorAll('.remove-file-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const index = parseInt(e.currentTarget.dataset.index);
                    attachedFilesArray.splice(index, 1);
                    updateAttachedFilesDisplay();
                });
            });
        } else {
            attachedFiles.style.display = 'none';
        }
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Event listener para input de arquivo
    if (arquivosInput) {
        arquivosInput.addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            attachedFilesArray = [...attachedFilesArray, ...files];
            updateAttachedFilesDisplay();
            e.target.value = ''; // Limpar input para permitir seleção do mesmo arquivo novamente
        });
    }

    // Funcionalidade de input de mensagem
    if (mensagemInput) {
        // Inicialmente esconder o botão
        sendButton.classList.add('hidden-send-button');

        mensagemInput.addEventListener('input', () => {
            const hasText = mensagemInput.value.trim().length > 0;
            const hasFiles = attachedFilesArray.length > 0;
            if (hasText || hasFiles) {
                sendButton.classList.remove('hidden-send-button');
            } else {
                sendButton.classList.add('hidden-send-button');
            }

            // Mostrar/esconder sugestões de prompt
            if (mensagemInput.value.startsWith('/')) {
                promptSuggestions.style.display = 'block';
            } else {
                promptSuggestions.style.display = 'none';
            }
        });

        mensagemInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (!sendButton.classList.contains('hidden-send-button')) {
                    enviarMensagem();
                }
            }
        });
    }

    // Funcionalidade de sugestões de prompt
    if (promptSuggestions) {
        document.querySelectorAll('.suggestion-item').forEach(item => {
            item.addEventListener('click', () => {
                const prompt = item.dataset.prompt;
                mensagemInput.value = prompt;
                promptSuggestions.style.display = 'none';
                mensagemInput.focus();
                // Disparar evento input para atualizar o botão
                mensagemInput.dispatchEvent(new Event('input'));
            });
        });
    }

    // Funcionalidade de dark mode
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            isDarkMode = !isDarkMode;
            document.body.classList.toggle('dark-mode', isDarkMode);
            const icon = darkModeToggle.querySelector('i');
            icon.className = isDarkMode ? 'fas fa-sun' : 'fas fa-moon';
            localStorage.setItem('darkMode', isDarkMode);
        });

        // Carregar preferência de dark mode
        const savedDarkMode = localStorage.getItem('darkMode') === 'true';
        if (savedDarkMode) {
            isDarkMode = true;
            document.body.classList.add('dark-mode');
            const icon = darkModeToggle.querySelector('i');
            icon.className = 'fas fa-sun';
        }
    }

    // Funcionalidade de compartilhar conversa
    if (shareBtn) {
        shareBtn.addEventListener('click', async () => {
            if (!currentConversationId) {
                alert('Selecione uma conversa para compartilhar.');
                return;
            }

            try {
                const response = await fetch(`/api/compartilhar/${currentConversationId}/`, {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': getCSRFToken()
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    const shareUrl = `${window.location.origin}/conversa-compartilhada/${data.share_id}/`;

                    // Copiar para clipboard
                    navigator.clipboard.writeText(shareUrl).then(() => {
                        alert('Link de compartilhamento copiado para a área de transferência!');
                    });
                }
            } catch (error) {
                console.error('Erro ao compartilhar conversa:', error);
                alert('Erro ao compartilhar conversa.');
            }
        });
    }

    // Funcionalidade de analytics
    if (analyticsBtn) {
        analyticsBtn.addEventListener('click', async () => {
            if (!currentConversationId) {
                alert('Selecione uma conversa para ver analytics.');
                return;
            }

            try {
                const response = await fetch(`/api/analytics/${currentConversationId}/`);
                if (response.ok) {
                    const data = await response.json();
                    mostrarAnalyticsModal(data);
                }
            } catch (error) {
                console.error('Erro ao carregar analytics:', error);
            }
        });
    }

    // Funcionalidade de configurações
    if (settingsBtn) {
        settingsBtn.addEventListener('click', () => {
            mostrarSettingsModal();
        });
    }

    // Funcionalidade de ações rápidas
    document.querySelectorAll('.quick-action-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const prompt = btn.dataset.prompt;
            mensagemInput.value = prompt;
            mensagemInput.focus();
            // Disparar evento input para atualizar o botão
            mensagemInput.dispatchEvent(new Event('input'));
        });
    });

    // Função para mostrar modal de analytics
    function mostrarAnalyticsModal(data) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content analytics-modal">
                <div class="modal-header">
                    <h3>Analytics da Conversa</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="analytics-grid">
                        <div class="analytics-item">
                            <div class="analytics-value">${data.total_mensagens}</div>
                            <div class="analytics-label">Total de Mensagens</div>
                        </div>
                        <div class="analytics-item">
                            <div class="analytics-value">${data.media_rating || 'N/A'}</div>
                            <div class="analytics-label">Avaliação Média</div>
                        </div>
                        <div class="analytics-item">
                            <div class="analytics-value">${data.total_reactions}</div>
                            <div class="analytics-label">Total de Reações</div>
                        </div>
                        <div class="analytics-item">
                            <div class="analytics-value">${data.tempo_medio_resposta || 'N/A'}</div>
                            <div class="analytics-label">Tempo Médio de Resposta</div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        modal.querySelector('.modal-close').addEventListener('click', () => {
            modal.remove();
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    // Função para mostrar modal de configurações
    function mostrarSettingsModal() {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content settings-modal">
                <div class="modal-header">
                    <h3>Configurações</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="settings-section">
                        <h4>Preferências de Chat</h4>
                        <div class="setting-item">
                            <label for="auto-scroll">Rolagem automática</label>
                            <input type="checkbox" id="auto-scroll" checked>
                        </div>
                        <div class="setting-item">
                            <label for="show-typing">Mostrar indicador de digitação</label>
                            <input type="checkbox" id="show-typing" checked>
                        </div>
                        <div class="setting-item">
                            <label for="sound-notifications">Notificações sonoras</label>
                            <input type="checkbox" id="sound-notifications">
                        </div>
                    </div>
                    <div class="settings-section">
                        <h4>Personalidade da IA</h4>
                        <select id="personalidade-setting" class="form-control">
                            <option value="">Carregando...</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" id="save-settings">Salvar</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Carregar personalidades no select
        if (personalidadeSelect) {
            const select = modal.querySelector('#personalidade-setting');
            select.innerHTML = personalidadeSelect.innerHTML;
            select.value = personalidadeSelect.value;
        }

        modal.querySelector('.modal-close').addEventListener('click', () => {
            modal.remove();
        });

        modal.querySelector('#save-settings').addEventListener('click', () => {
            // Salvar configurações
            const settings = {
                autoScroll: modal.querySelector('#auto-scroll').checked,
                showTyping: modal.querySelector('#show-typing').checked,
                soundNotifications: modal.querySelector('#sound-notifications').checked,
                personalidade: modal.querySelector('#personalidade-setting').value
            };

            localStorage.setItem('chatSettings', JSON.stringify(settings));

            if (personalidadeSelect) {
                personalidadeSelect.value = settings.personalidade;
            }

            modal.remove();
            alert('Configurações salvas!');
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
    // Funcionalidade da Sidebar
    if (toggleSidebarBtn && sidebar && sidebarOverlay) {
        function toggleSidebar() {
            const isActive = sidebar.classList.contains('active');
            if (isActive) {
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            } else {
                sidebar.classList.add('active');
                sidebarOverlay.classList.add('active');
            }
        }

        toggleSidebarBtn.addEventListener('click', toggleSidebar);
        sidebarOverlay.addEventListener('click', toggleSidebar);

        // Fechar sidebar ao clicar em uma conversa (mobile)
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && sidebar.classList.contains('active')) {
                if (e.target.closest('.conversation-item-wrapper')) {
                    setTimeout(() => {
                        sidebar.classList.remove('active');
                        sidebarOverlay.classList.remove('active');
                    }, 300);
                }
            }
        });
    }

    // Funcionalidade de Drag da Área de Input
    const dragHandle = document.querySelector('.drag-handle');
    const chatInputArea = document.querySelector('.chat-input-area');
    let isDragging = false;
    let startY = 0;
    let currentBottom = 0;

    if (dragHandle && chatInputArea) {
        dragHandle.addEventListener('mousedown', (e) => {
            isDragging = true;
            startY = e.clientY;
            currentBottom = parseInt(window.getComputedStyle(chatInputArea).bottom) || 0;
            document.body.style.cursor = 'ns-resize';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                const deltaY = startY - e.clientY; // Inverted because dragging up increases bottom
                const newBottom = Math.max(0, currentBottom + deltaY);
                chatInputArea.style.bottom = newBottom + 'px';
            }
        });

        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                document.body.style.cursor = '';
            }
        });

        // Para touch
        dragHandle.addEventListener('touchstart', (e) => {
            isDragging = true;
            startY = e.touches[0].clientY;
            currentBottom = parseInt(window.getComputedStyle(chatInputArea).bottom) || 0;
            e.preventDefault();
        });

        document.addEventListener('touchmove', (e) => {
            if (isDragging) {
                const deltaY = startY - e.touches[0].clientY;
                const newBottom = Math.max(0, currentBottom + deltaY);
                chatInputArea.style.bottom = newBottom + 'px';
            }
        });

        document.addEventListener('touchend', () => {
            if (isDragging) {
                isDragging = false;
            }
        });
    }

    carregarConversas();
    carregarPersonalidades();
});